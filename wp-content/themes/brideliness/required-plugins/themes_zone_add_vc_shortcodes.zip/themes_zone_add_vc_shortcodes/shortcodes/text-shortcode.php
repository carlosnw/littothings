<?php 

/* Add Shortcode in text widget */
add_filter('widget_text', 'do_shortcode');
